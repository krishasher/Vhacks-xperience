import { ContainerBlot } from 'parchment';

class Container extends ContainerBlot {}

export default Container;
