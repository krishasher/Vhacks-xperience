export default new WeakMap();
